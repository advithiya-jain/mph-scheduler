CREATE DATABASE `mph_scheduling` /*!40100 DEFAULT CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci */ /*!80016 DEFAULT ENCRYPTION='N' */;

-- MySQL dump 10.13  Distrib 8.0.23, for macos10.15 (x86_64)
--
-- Host: localhost    Database: mph_scheduling
-- ------------------------------------------------------
-- Server version	8.0.23

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `default_schedule`
--

DROP TABLE IF EXISTS `default_schedule`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `default_schedule` (
  `lesson_id` int NOT NULL AUTO_INCREMENT,
  `t_name` varchar(45) DEFAULT NULL,
  `t_class` varchar(45) DEFAULT NULL,
  `grade` varchar(45) DEFAULT NULL,
  `date` varchar(45) DEFAULT NULL,
  `time` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`lesson_id`),
  CONSTRAINT `default_schedule_ibfk_1` FOREIGN KEY (`lesson_id`) REFERENCES `teacher_details` (`id_teacher`)
) ENGINE=InnoDB AUTO_INCREMENT=93886 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `default_schedule`
--

LOCK TABLES `default_schedule` WRITE;
/*!40000 ALTER TABLE `default_schedule` DISABLE KEYS */;
INSERT INTO `default_schedule` VALUES (93879,'Olivia-Mae Barrett','Economics','D1','2021-04-21','08:00'),(93881,'Tulisa Sharma','Sciences','M4','2021-04-21','11:20'),(93882,'Rahul Cullen','Individuals & Societies','M5','2021-04-21','13:40'),(93884,'Manraj Rowe','Individuals & Societies','M3','2021-04-22','08:00');
/*!40000 ALTER TABLE `default_schedule` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_details`
--

DROP TABLE IF EXISTS `student_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_details` (
  `student_id` int NOT NULL AUTO_INCREMENT,
  `student_name` varchar(45) DEFAULT NULL,
  `student_grade` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83780 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_details`
--

LOCK TABLES `student_details` WRITE;
/*!40000 ALTER TABLE `student_details` DISABLE KEYS */;
INSERT INTO `student_details` VALUES (83728,'Conall Salgado','M1'),(83729,'Caprice Vazquez','M2'),(83730,'Kaylan Cruz','M3'),(83731,'Casey Brooks','M4'),(83732,'Corrie Wallace','M5'),(83733,'Ioan Hall','D1'),(83734,'Makayla Kearns','D2'),(83735,'Morgan Lim','M1'),(83736,'Abi Webster','M2'),(83737,'Andre Drew','M3'),(83738,'Ayva Houghton','M4'),(83739,'Keaton Fitzpatrick','M5'),(83740,'Izaan Chase','D1'),(83741,'Maya Williams','D2'),(83742,'Connar Horn','M1'),(83743,'Lily-Anne Person','M2'),(83744,'Zakaria Key','M3'),(83745,'Bryony Short','M4'),(83746,'Geoffrey Galindo','M5'),(83747,'Coral Rosario','D1'),(83748,'Isla Mora','D2'),(83749,'Denny Solis','M1'),(83750,'Milena Albert','M2'),(83751,'Matthew Molloy','M3'),(83752,'Harvir Mcgill','D1'),(83753,'Alessio Rubio','D2');
/*!40000 ALTER TABLE `student_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `student_login`
--

DROP TABLE IF EXISTS `student_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `student_login` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `student_login_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `student_details` (`student_id`)
) ENGINE=InnoDB AUTO_INCREMENT=83754 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `student_login`
--

LOCK TABLES `student_login` WRITE;
/*!40000 ALTER TABLE `student_login` DISABLE KEYS */;
INSERT INTO `student_login` VALUES (83728,'conallsalgado','9EuWDjYN'),(83729,'capricevazquez','WDBK8sbM'),(83730,'kaylancruz','uSbKWMVv'),(83731,'caseybrooks','AGYqUDFg'),(83732,'corriewallace','pLZm7CTr'),(83733,'ioanhall','Eg7kU6Na'),(83734,'makaylakearns','WjLCk6Wj'),(83735,'morganlim','5tgpJnQB'),(83736,'abiwebster','BW9seycA'),(83737,'andredrew','dALwyjBp'),(83738,'ayvahoughton','6f4udyRb'),(83739,'keatonfitzpatrick','Q5X8mkzt'),(83740,'izaanchase','m8SbarEb'),(83741,'mayawilliams','SrNXUEvY'),(83742,'connarhorn','cL2xyfLK'),(83743,'lily-anneperson','bReCD4Dk'),(83744,'zakariakey','9fPfbkYV'),(83745,'bryonyshort','bdwEPKCQ'),(83746,'geoffreygalindo','3BHn7xYP'),(83747,'coralrosario','ajUpP5tf'),(83748,'islamora','d4zG8GQc'),(83749,'dennysolis','UyN9RByW'),(83750,'milenaalbert','Af7LG3Bj'),(83751,'matthewmolloy','A9dDf97z'),(83752,'harvirmcgill','UWxnJSBk'),(83753,'alessiorubio','GBkjgcED');
/*!40000 ALTER TABLE `student_login` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_details`
--

DROP TABLE IF EXISTS `teacher_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_details` (
  `id_teacher` int NOT NULL AUTO_INCREMENT,
  `teacher_name` varchar(45) DEFAULT NULL,
  `teacher_class` varchar(45) DEFAULT NULL,
  `teacher_grades` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id_teacher`),
  KEY `teacher_grades` (`teacher_grades`)
) ENGINE=InnoDB AUTO_INCREMENT=93933 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_details`
--

LOCK TABLES `teacher_details` WRITE;
/*!40000 ALTER TABLE `teacher_details` DISABLE KEYS */;
INSERT INTO `teacher_details` VALUES (93877,'Ammar Chadwick','Maths AI HL','D1 D2'),(93878,'Saffron Costa','Maths AI SL','D1 D2'),(93879,'Krystian Diaz','Visual Arts','D1 D2'),(93880,'Lilian Moyer','Maths','M1 M2 M3 M4 M5'),(93881,'Patsy Hancock','Maths AA HL','D1 D2'),(93882,'Iram Robles','Business Management','D1 D2'),(93883,'Dolly Hunter','Design','M1 M2 M3 M4 M5'),(93884,'Olivia-Mae Barrett','Economics','D1 D2'),(93885,'Zaydan Clarke','Maths AA SL','D1 D2'),(93886,'Sameer Derrick','Psychology','D1 D2'),(93887,'Kairon Lawson','Computer Science','D1 D2'),(93888,'Youssef Massey','Geography','D1 D2'),(93889,'Salman Povey','Biology','M1 M2 M3 M4 M5 D1 D2'),(93890,'Abdulahi Roth','Physics','M4 M5 D1 D2'),(93891,'Kaira Ellwood','History','M4 M5 D1 D2'),(93892,'Lex Dickinson','Chemistry','M3 M4 M5 D1 D2'),(93893,'Tessa Davey','Physical Education','M1 M2 M3 M4 M5 D1 D2'),(93894,'Tiana Sharpe','English','M1 M2 M3 M4 M5'),(93895,'Tai Finch','English','D1 D2'),(93896,'Rhia Manning','French','M3 M4 M5'),(93897,'Raya Knapp','French','D1 D2'),(93898,'Cerys Bell','French','M1 M2 M3 M4 M5'),(93899,'Tulisa Sharma','Sciences','M1 M2 M3 M4 M5'),(93900,'Efan Welch','Arts','M1 M2 M3 M4 M5'),(93901,'Rahul Cullen','Individuals & Societies','M3 M4 M5'),(93902,'Manraj Rowe','Individuals & Societies','M1 M2 M3 M4 M5');
/*!40000 ALTER TABLE `teacher_details` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `teacher_login`
--

DROP TABLE IF EXISTS `teacher_login`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `teacher_login` (
  `user_id` int NOT NULL,
  `username` varchar(45) DEFAULT NULL,
  `password` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`user_id`),
  CONSTRAINT `teacher_login_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `teacher_details` (`id_teacher`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `teacher_login`
--

LOCK TABLES `teacher_login` WRITE;
/*!40000 ALTER TABLE `teacher_login` DISABLE KEYS */;
INSERT INTO `teacher_login` VALUES (93877,'ammarchadwick','pY9DNmBN'),(93878,'saffroncosta','Fw3VBUdC'),(93879,'krystiandiaz','GaFzHDb4'),(93880,'lilianmoyer','YUMbJkuU'),(93881,'patsyhancock','AgjDQj2X'),(93882,'iramrobles','UW2CMssz'),(93883,'dollyhunter','QPZWnbJa'),(93884,'olivia-maebarrett','fy4crsFv'),(93885,'zaydanclarke','pRzrneLT'),(93886,'sameerderrick','U36FyFjF'),(93887,'kaironlawson','e6VPYP5p'),(93888,'youssefmassey','t9V4AVCY'),(93889,'salmanpovey','NvFAuchu'),(93890,'abdulahiroth','xKU4UAhN'),(93891,'kairaellwood','xzEX3EvX'),(93892,'lexdickinson','Jh6CNfgb'),(93893,'tessadavey','dMGaHxZ7'),(93894,'tianasharpe','Dk3bgtXF'),(93895,'taifinch','2HKcF9AW'),(93896,'rhiamanning','MJZFBZNF'),(93897,'rayaknapp','7jggUdWv'),(93898,'cerysbell','FNgd59tT'),(93899,'tulisasharma','WvXRgn8m'),(93900,'efanwelch','rysM22J4'),(93901,'rahulcullen','5RMpSxs2'),(93902,'manrajrowe','M8gcf6GM');
/*!40000 ALTER TABLE `teacher_login` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2021-04-17 11:52:51
